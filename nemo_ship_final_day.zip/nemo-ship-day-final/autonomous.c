#include <stdio.h>
#include "ifi_frc.h"
#include "pwm.h"
#include "timers.h"
#include "interrupts.h"
#include "serial_ports.h"
#include "ifi_code.h"
#include "autonomous.h"

#include "catlin.h"

//Different hydrid modes
#define AUTO_MOVE HYBRIDMODE1
#define GET_BALL HYBRIDMODE2

//Different actions
#define NUDGE_LEFT 0
#define NUDGE_RIGHT 1
#define NUDGE_FORWARD 2
#define TURN_LEFT 3

#define DEADMAN_TIMELIM (CALLSPSEC * 5)

static int auto_move_allowed = TRUE;

static void read_IR(void);
static void update_hybrid_state(void);

static struct action_queue queue;

void Autonomous_Init(void)
{
	init_action_queue(&queue);
	if(GET_BALL) {
		liftRaise();
		queue_pause(&queue, 1.0);	//Will be commented out when playing on a full field
	}
}

void Autonomous(void)
{
	compressor();
	
	mecanumDrive(127, 127, 127);	//default to doing nothing
	
	update_hybrid_state();
	
	read_IR();	//IR commands override EVERYTHING
}

static void read_IR(void)
{
	static int nudge_timer = 0;
	static int nudge_dir;
	static int last_command_time = 0;	//Time since last command given
	int forward_speed;
	
	if(last_command_time < DEADMAN_TIMELIM)
		last_command_time++;
	else
		auto_move_allowed = FALSE;
	
	if(IRGREEN) {
		nudge_timer = 8;
		nudge_dir = NUDGE_RIGHT;
		auto_move_allowed = TRUE;
		last_command_time = 0;
	}
	if(IRYELLOW) {
		nudge_timer = 8;
		nudge_dir = NUDGE_LEFT;
		auto_move_allowed = TRUE;
		last_command_time = 0;
	}
	if(IRORANGE) {
		if(AUTO_MOVE) {
			auto_move_allowed = FALSE;
		} else {
			nudge_timer = 15;
			nudge_dir = NUDGE_FORWARD;
		}
		last_command_time = 0;
	}
	if(IRBLUE) {
		nudge_timer = 8;
		nudge_dir = TURN_LEFT;
		auto_move_allowed = TRUE;
		liftRaise();
		last_command_time = 0;
	}
	
	if(!GET_BALL)	//If we're not getting the ball, then go forward really fast
		forward_speed = 127 + 100;
	else
		forward_speed = 127 + 50;
	
	if(nudge_timer > 0) {
		nudge_timer--;
		if(nudge_dir == NUDGE_RIGHT)
			mecanumDrive(127, forward_speed, 127 + 50);
		if(nudge_dir == NUDGE_LEFT)
			mecanumDrive(127, forward_speed, 127 - 50);
		if(nudge_dir == NUDGE_FORWARD)
			mecanumDrive(127, forward_speed, 127);
		if(nudge_dir == TURN_LEFT)
			mecanumDrive(127, 127, 127 + 50);
	}
	
#if DEBUGPERSON == KEVIN
	User_Byte1 = IRORANGE;
	User_Byte2 = IRYELLOW;
	User_Byte3 = IRGREEN;
	User_Byte4 = IRBLUE;
	User_Byte5 = AUTO_MOVE;
	User_Byte6 = GET_BALL;
#endif
}

static void update_hybrid_state(void)
{
	static int state = 0;
	switch(state) {
		case 0:
			if(is_action_queue_done(&queue))
				state = 1;
			break;
		case 1:
			if(AUTO_MOVE && auto_move_allowed)
				mecanumDrive(127, 180, 127);
			if(GET_BALL && (WOBBLEFRONTLEFT == WOBBLETRUE || WOBBLEFRONTRIGHT == WOBBLETRUE)) {
				//The following line is commented out because it's no longer a good idea to capture the ball
				//state = 2;
			}
			break;
		/*case 2:
			if(WOBBLEREARLEFT == WOBBLETRUE || WOBBLEREARRIGHT == WOBBLETRUE)
				state = 3;
			break;
		case 3:
			if(WOBBLEFRONTLEFT == WOBBLETRUE || WOBBLEFRONTRIGHT == WOBBLETRUE)
				state = 4;
			break;
		case 4:
			if(WOBBLEREARLEFT == WOBBLETRUE || WOBBLEREARRIGHT == WOBBLETRUE) {
				queue_pneumatics(&queue, LOWER_PLATFORM);
				queue_pause(&queue, 0.3);
				queue_pneumatics(&queue, RIGHT_REAR_HOLDER_UP | RIGHT_FRONT_HOLDER_UP | LEFT_REAR_HOLDER_UP | LEFT_FRONT_HOLDER_UP);
				state = 5;
			}*/
		case 5:
			break;
	}
	
	update_action_queue(&queue);
}

void Autonomous_Spin(void)
{

}
