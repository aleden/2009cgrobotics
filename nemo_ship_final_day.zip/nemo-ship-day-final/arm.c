/*******************************************************************************
* FILE NAME: arm.c
*
* DESCRIPTION:
*  This file contains the code for the arm.
*
* USAGE:
*	To be included in catlin routines
*
*  Written by Rohan Jhunjhunwala
*
*******************************************************************************/
#include "catlin.h"
#include "stdio.h"

#define UP		10
#define DOWN 	-10

int currentArmState = ARMSTOPPED;
int armSideOfStore = ARMBELOWSTORE;
int targetArmState;
int inProgToState;
int direction;
int armUpSpeed = ARMFULLUPSPEED;
int armDownSpeed = ARMFULLDOWNSPEED;

void changeArmState(int changeTo)
{
	switch (changeTo)
	{		
		case ARMSTOPBOTTOM:
			BRAKERELAY = BRAKEENGAGED;
			ARMMOTOR = ARMSTOPSPEED;
			currentArmState = ARMSTOPBOTTOM;
			break;
		
		case ARMSTOPSTORE:
			BRAKERELAY = BRAKEENGAGED;
			ARMMOTOR = ARMSTOPSPEED;
			currentArmState = ARMSTOPSTORE;
			break;
		
		case ARMSTOPTOP:
			BRAKERELAY = BRAKEENGAGED;
			ARMMOTOR = ARMSTOPSPEED;
			currentArmState = ARMSTOPTOP;
			break;			

		case ARMSTOPPED:
			BRAKERELAY = BRAKEENGAGED;
			ARMMOTOR = ARMSTOPSPEED;
			currentArmState = ARMSTOPPED;
			break;
	
		case ARMMOVEUP:
			BRAKERELAY = BRAKERELEASED;
			ARMMOTOR = armUpSpeed;
			currentArmState = ARMMOVEUP;
			break;
	
		case ARMMOVEDOWN:
			BRAKERELAY = BRAKERELEASED;
			ARMMOTOR = armDownSpeed;
			currentArmState = ARMMOVEDOWN;
			break;

		default:
			#if DEBUGPERSON == ROHAN
			Switch1_LED = 1;
			#endif
			break;
	}
}

void requestArmState(int reqState)
{
	if (getWristState() == WRISTRAISED)
	{
		return;
	}
	#if DEBUGPERSON == ROHAN
		User_Byte1 = getWristState();
	#endif
	switch (reqState)
	{
		case ARMSTOPBOTTOM:
		targetArmState = ARMSTOPBOTTOM;
		inProgToState = ARMSTOPBOTTOM;
			switch (currentArmState)
			{
				case ARMSTOPBOTTOM: 
				case ARMMOVEDOWN:
					break;

				case ARMMOVEUP:
				case ARMSTOPPED:
				case ARMSTOPSTORE:
				case ARMSTOPTOP:
					changeArmState(ARMMOVEDOWN);
					break;
				
				default:
					#if DEBUGPERSON == ROHAN
					Switch1_LED = 1;
					#endif
					break;
			}
			break;
			
		case ARMSTOPTOP:
		inProgToState = ARMSTOPTOP;
		targetArmState = ARMSTOPTOP;
			switch (currentArmState)
			{
				
				case ARMSTOPPED:
				case ARMSTOPBOTTOM: 
				case ARMMOVEDOWN:
				case ARMSTOPSTORE:
					changeArmState(ARMMOVEUP);					
					break;
					
				case ARMMOVEUP: 
				case ARMSTOPTOP:
					break;

				default:
					#if DEBUGPERSON == ROHAN
					Switch1_LED = 1;
					#endif
					break;
			}
			break;
		case ARMSTOPSTORE:
		inProgToState = ARMSTOPSTORE;
		targetArmState = ARMSTOPSTORE;
			switch (currentArmState)
			{
				case ARMSTOPBOTTOM: 
					changeArmState(ARMMOVEUP);					
					break;

				case ARMSTOPTOP: 
					changeArmState(ARMMOVEDOWN);
					break;

				case ARMSTOPSTORE:
					break;

				case ARMMOVEUP:
				case ARMMOVEDOWN:
				case ARMSTOPPED:
					if (armSideOfStore == ARMABOVESTORE)
					{
						changeArmState(ARMMOVEDOWN);
					}
					else if (armSideOfStore == ARMBELOWSTORE)
					{
						changeArmState(ARMMOVEUP);
					}
					break;

				default:
					#if DEBUGPERSON == ROHAN
					Switch1_LED = 1;
					#endif
					break;
			}
			break;

		case ARMSTOPPED:
		targetArmState = ARMSTOPPED;
			switch (currentArmState)
			{
				case ARMMOVEUP: 
				case ARMMOVEDOWN:
					changeArmState(ARMSTOPPED);					
`					break;

				case ARMSTOPBOTTOM: 
				case ARMSTOPSTORE: 
				case ARMSTOPTOP: 
				case ARMSTOPPED:
					break;

				default:
					#if DEBUGPERSON == ROHAN
					Switch1_LED = 1;
					#endif
					break;
			}
			break;
			
		case ARMMOVEUP:
		targetArmState = ARMMOVEUP;
		inProgToState = REACHEDSTATE;
			switch (currentArmState)
			{
				case ARMSTOPPED:
				case ARMMOVEDOWN:
				case ARMSTOPBOTTOM:
				case ARMSTOPSTORE:
					changeArmState(ARMMOVEUP);					
					break;

				case ARMSTOPTOP:
				case ARMMOVEUP:
					break;

				default:
					#if DEBUGPERSON == ROHAN
					Switch1_LED = 1;
					#endif
					break;
			}
			break;
	
		case ARMMOVEDOWN:
		targetArmState = ARMMOVEDOWN;
		inProgToState = REACHEDSTATE;
			switch (currentArmState)
			{
				case ARMSTOPPED:
				case ARMMOVEUP:
				case ARMSTOPTOP:
				case ARMSTOPSTORE:
					changeArmState(ARMMOVEDOWN);					
					break;

				case ARMSTOPBOTTOM:
				case ARMMOVEDOWN:
					break;

				default:
					#if DEBUGPERSON == ROHAN
					Switch1_LED = 1;
					#endif
					break;
			}
			break;
		
		default:
			#if DEBUGPERSON == ROHAN
			Switch1_LED = 1;
			#endif
			break;
	}
}


void monitorArmSensors(void)
{
	armUpSpeed = ARMFULLUPSPEED;
	armDownSpeed = ARMFULLDOWNSPEED;
	if (inProgToState == currentArmState)
	{
		inProgToState == REACHEDSTATE;
	}
	
	if (ARMMOTOR > ARMSTOPSPEED+10)
	{
		direction = UP;
	}
	else if (ARMMOTOR < ARMSTOPSPEED-10)
	{
		direction = DOWN;
	}
	
	if (direction == UP && MIDDLEARMLIMIT == TRIPLIM)
	{
		armSideOfStore = ARMABOVESTORE;
	}
	else if (direction == DOWN && MIDDLEARMLIMIT == TRIPLIM)
	{
		armSideOfStore = ARMBELOWSTORE;
	}
	
	if (targetArmState == ARMSTOPSTORE)
	{
		if (MIDDLEARMLIMIT == TRIPLIM)
		{
			changeArmState(ARMSTOPSTORE);
		}
		if (MIDDLEARMLIMIT != TRIPLIM && currentArmState == ARMSTOPSTORE)
		{
			if (armSideOfStore == ARMABOVESTORE)
			{
				armDownSpeed = ARMSLOWDOWNSPEED;
				changeArmState(ARMMOVEDOWN);
			}
			else if (armSideOfStore == ARMBELOWSTORE)
			{
				armUpSpeed = ARMSLOWUPSPEED;
				changeArmState(ARMMOVEUP);
			}
		}
	}
	
	if ((MIDDLEARMLIMIT == TRIPLIM) && (targetArmState == ARMSTOPSTORE))
	{
		changeArmState(ARMSTOPSTORE);
	}
	if ((TOPARMLIMIT == TRIPLIM) && ((targetArmState == ARMSTOPTOP)||(currentArmState == ARMMOVEUP)))
	{
		changeArmState(ARMSTOPTOP);
	}

	if ((BOTTOMARMLIMIT == TRIPLIM) && ((targetArmState == ARMSTOPBOTTOM)||(currentArmState == ARMMOVEDOWN)))
	{
		changeArmState(ARMSTOPBOTTOM);
	}
	#if DEBUGPERSON == ROHAN
	//User_Byte1 = armSideOfStore;
	User_Byte2 = MIDDLEARMLIMIT;
	User_Byte3 = currentArmState;
	User_Byte4 = targetArmState;
	User_Byte5 = direction;
	User_Byte6 = BOTTOMARMLIMIT;
	#endif
	
}

void monitorArmUi(void)
{
	if (ARMHEIGHTSWITCH < ARMGOUP+5 && ARMHEIGHTSWITCH > ARMGOUP-5)
	{
		requestArmState(ARMMOVEUP);
	}
	else if (ARMHEIGHTSWITCH < ARMGODOWN+5 && ARMHEIGHTSWITCH > ARMGODOWN-5)
	{
		requestArmState(ARMMOVEDOWN);
	}
	else if ((ARMHEIGHTSWITCH < ARMSTOP+5 && ARMHEIGHTSWITCH > ARMSTOP-5)&&(inProgToState == REACHEDSTATE))
	{
		requestArmState(ARMSTOPPED);
	}
	else if (ARMHEIGHTSWITCH < ARMGOHIGH+5 && ARMHEIGHTSWITCH > ARMGOHIGH-5)
	{
		requestArmState(ARMSTOPTOP);
	}
	else if (ARMHEIGHTSWITCH < ARMGOSTORE+5 && ARMHEIGHTSWITCH > ARMGOSTORE-5)
	{
		requestArmState(ARMSTOPSTORE);
	}
	else if (ARMHEIGHTSWITCH < ARMGOLOW+5 && ARMHEIGHTSWITCH > ARMGOLOW-5)
	{
		requestArmState(ARMSTOPBOTTOM);
	}
}

int getArmState(void)
{
	return currentArmState;
}
