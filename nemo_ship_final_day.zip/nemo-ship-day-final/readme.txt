This is experimental software and the author cannot
assume any responsibility for its use (or misuse).

Furthermore, this code is *not* supported by IFI or FIRST.

This software was built using MPLAB 8.00 and C18 version 3.10.
Until Microchip fixes a few problems with header files, I
wouldn't suggest upgrading to any version later than 3.10.

Before upgrading your compiler, you might consider copying
your entire mcc18 directory to a backup directory. Once
backed-up, you can apply the free upgrade to 3.10 that can
be found on Microchip's website:

http://ww1.microchip.com/downloads/en/DeviceDoc/MPLAB-C18-Upgrade-doc-v3_10.exe
 

More documentation to come...