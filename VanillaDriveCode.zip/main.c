#define _FRC_BOARD

#include "BuiltIns.h"
#include "API.h"
#include "types.h"

#define BOOL unsigned char
#define TRUE 1
#define FAlSE 0

#define MTR_ID_LEFT  1
#define MTR_ID_RIGHT 2

#define MTRSPD_STOP       127
#define MTRSPD_L_FORWARD  0
#define MTRSPD_L_REVERSE
#define MTRSPD_L_BACK     255

#define MTRSPD_R_FORWARD 255
//#define MTRSPD_R_REVERSE
#define MTRSPD_R_BACK    0

#define REVERSE_MOTOR_SPEED(MTRSPEED) (MTRSPEED) = (255 - (MTRSPEED))

#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) > (b) ? (b) : (a))
#define ABS(a) ((a) < 0 ? (-(a)) : (a))

#define DEADRANGE 20
#define DEADZONE(num) (((num) >= (127-DEADRANGE) && (num) <= (127+DEADRANGE)) ? 127 : (num))

#define JOYSTICK_PORT 4

#define TURBO_MODE
#define TURBO_INCREASE (127/4)

//#define DEBUG_PRINT

void DriveSingleJoystick(void);

/*
* This function must be here for a competition project. It is
* automatically referenced by WPILib at startup and run. At that
* point the SetCompetitionMode function sets the competition
* mode. Basically, a mode of 0 is the default (without the
* IO_Initialization function) and runs a main function only.
* SetCompetitionMode(1) runs a competition project as shown.
*/
void IO_Initialization(void)
{
    SetCompetitionMode(1);
}

/*
* Initialize is run immediately when the robot is powered on
* regardless of the field mode.
*/
void Initialize(void)
{
}

/*
* Autonomous is run as soon as the field controls enable the
* robot. At the end of the autonomous period, the Autonomous
* function will end (note: even if it is in an infinite loop
* as in the example, it will be stopped).
*/
void Autonomous(void)
{
}

/*
* The OperatorControl function will be called when the field
* switches to operator mode. If the field ever switches back
* to autonomous, then OperatorControl will automatically exit
* and the program will transfer control to the Autonomous
* function.
*/
void OperatorControl(void)
{
	DriveSingleJoystick();
}

void DriveSingleJoystick(void)
{
#ifdef DEBUG_PRINT
	UInt32 c;
#endif

#ifdef TURBO_MODE
	BOOL turboMode = GetOIDInput(JOYSTICK_PORT, TRIGGER_SW);
#endif

	Int32 mtrLSpd = MTRSPD_STOP;
	Int32 mtrRSpd = MTRSPD_STOP;
	
	Int32 joyX = DEADZONE(GetOIAInput(JOYSTICK_PORT, X_AXIS));
	Int32 joyY = DEADZONE(GetOIAInput(JOYSTICK_PORT, Y_AXIS));
	
	Int32 vJoyX = joyX - 127;
	Int32 vJoyY = joyY - 127;
	
#ifdef TURBO_MODE
	if (!turboMode)
	{
		vJoyY /= 3;
		vJoyX /= 2;
	}
#endif

	mtrLSpd += vJoyY;
	mtrRSpd += vJoyY;
	
	mtrLSpd += vJoyX;
	mtrRSpd -= vJoyX;

#ifdef DEBUG_PRINT
	if (c < 999*3)
	{
		++c;
	}
	else
	{
#ifdef TURBO_MODE
		printf(turboMode != 0 ? "[%d, %d] (%d, %d) | turboModeON\r" :
		                        "[%d, %d] (%d, %d) | turboModeOFF\r",
		       mtrLSpd, mtrRSpd, joyX, joyY), c = 0;
#else
		printf("(%d, %d)\r", joyX, joyY), c = 0;
#endif
	}
#endif

#if TURBO_MODE0
	if (!turboMode)
	{
		if (mtrLSpd > (127 + TURBO_INCREASE) && mtrRSpd > (127 + TURBO_INCREASE))
		{
			mtrRSpd -= TURBO_INCREASE;
			mtrLSpd -= TURBO_INCREASE;
		}
		
		mtrLSpd = DEADZONE(mtrLSpd);
		mtrRSpd = DEADZONE(mtrRSpd);
	}
#endif
	
	mtrLSpd = MIN(255, MAX(mtrLSpd, 0));
	mtrRSpd = MIN(255, MAX(mtrRSpd, 0));

#ifdef MTRSPD_L_REVERSE
	REVERSE_MOTOR_SPEED(mtrLSpd);
#endif
	
#ifdef MTRSPD_R_REVERSE
	REVERSE_MOTOR_SPEED(mtrRSpd);
#endif
	
	SetPWM(MTR_ID_LEFT,  (UByte)mtrLSpd);
	SetPWM(MTR_ID_RIGHT, (UByte)mtrRSpd);
}

/*
* the main program is not used, but needs to be here to
* statisfy a reference to it. This requirement will probably
* go away in the next version of WPILib.
*/
void main(void)
{
}
